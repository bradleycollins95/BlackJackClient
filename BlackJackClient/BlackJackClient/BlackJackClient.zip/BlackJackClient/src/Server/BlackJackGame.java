package Server;

import Cards.DeckOfCards;
import Players.Dealer;
import Players.Player;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

/**
 * Handles game logic for a single client in a separate thread
 * This class implements the Runnable interface to be executed by a thread
 *
 * @author bradley.collins
 */
public class BlackJackGame implements Runnable {
    private final Socket socket;
    private final Player player;
    private final Dealer dealer;
    private DeckOfCards deck;

    /**
     * Constructs a Blackjack game with a specified client socket
     *
     * @param socket The client socket connected to the server
     */
    public BlackJackGame(Socket socket) {
        this.socket = socket;
        this.player = new Player(100);
        this.dealer = new Dealer();
        this.deck = new DeckOfCards();
    }

    @Override
    public void run() {
        //ensure streams are closed properly
        try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

            System.out.println("Welcome to Blackjack!");
            System.out.println("""
                Rules:
                
                - Blackjack hands are scored by their point total.\s
                - The hand with the highest total wins as long as it doesn't exceed 21.\s
                - A hand with a higher total than 21 is said to bust.\s
                - Cards 2 through 10 are worth their face value, and face cards (jack, queen, king) are also worth 10.
                """);
            System.out.println("You start with $100.");
            String inputLine;
            while (player.getMoney() > 0) {
                System.out.println("\nPlace your bet:");
                int bet = Integer.parseInt(in.readLine());

                if (bet > player.getMoney()) {
                    System.out.println("You cannot bet more than you have.");
                    continue;
                }

                startNewGame();

                System.out.println("Your hand: " + player);
                System.out.println("Dealer's hand: " + dealer.getCards().get(0) + " and [hidden]");

                boolean playerTurn = true;
                while (playerTurn) {
                    System.out.println("Hit or stand?");
                    inputLine = in.readLine();

                    if (inputLine.equalsIgnoreCase("hit")) {
                        player.addCard(deck.drawCard());
                        System.out.println("Your hand: " + player);
                        if (player.calculateValue() > 21) {
                            System.out.println("You bust!");
                            player.newBalance(-bet);
                            playerTurn = false;
                        }
                    } else if (inputLine.equalsIgnoreCase("stand")) {
                        playerTurn = false;
                    } else {
                        System.out.println("Invalid input! Please type 'hit' to hit, or 'stand' to stand.");
                    }
                }

                if (player.calculateValue() <= 21) {
                    dealer.hit(deck);
                    System.out.println("Dealer's hand: " + dealer);

                    if (dealer.calculateValue() > 21 || dealer.calculateValue() < player.calculateValue()) {
                        System.out.println("You win!");
                        player.newBalance(bet);
                    } else if (dealer.calculateValue() > player.calculateValue()) {
                        System.out.println("Dealer wins!");
                        player.newBalance(-bet);
                    } else {
                        System.out.println("It's a tie!");
                    }
                }

                System.out.println("Your current money: $" + player.getMoney());
                System.out.println("Do you want to play again? (y/n)");
                inputLine = in.readLine();
                if (inputLine.equalsIgnoreCase("n")) {
                    break;
                }
            }

            System.out.println("Game over! You finished with $" + player.getMoney());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void startNewGame() {
        player.clear();
        dealer.clear();
        deck = new DeckOfCards();

        player.addCard(deck.drawCard());
        player.addCard(deck.drawCard());

        dealer.addCard(deck.drawCard());
        dealer.addCard(deck.drawCard());
    }
}
